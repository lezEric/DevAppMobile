package br.com.up.giragarrafa.repositories;

public class ResultadoRepository {
}
