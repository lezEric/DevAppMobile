package br.com.up.giragarrafa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    private Button button;

    private String player_1, player_2, player_3, player_4;


    private TextInputEditText player1;
    private TextInputEditText player2;
    private TextInputEditText player3;
    private TextInputEditText player4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.play_button);
        player1 = findViewById(R.id.player_1_text);
        player2 = findViewById(R.id.player_2_text);
        player3 = findViewById(R.id.player_3_text);
        player4 = findViewById(R.id.player_4_text);


        button.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v){
                playGame();
            }
        });

        }
    public void playGame() {
        player_1 = player1.getText().toString().trim();
        player_2 = player2.getText().toString().trim();
        player_3 = player3.getText().toString().trim();
        player_4 = player4.getText().toString().trim();

        Intent intent = new Intent(MainActivity.this, GiraGarrafa.class);
        intent.putExtra(GiraGarrafa.PLAYER1,player_1);
        intent.putExtra(GiraGarrafa.PLAYER2,player_2);
        intent.putExtra(GiraGarrafa.PLAYER3,player_3);
        intent.putExtra(GiraGarrafa.PLAYER4,player_4);

        startActivity(intent);
    }
}