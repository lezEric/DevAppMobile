package br.com.up.giragarrafa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Random;





public class GiraGarrafa extends AppCompatActivity {
        private ImageView garrafa;
        private Random random = new Random();
        public int ultDir;
        private boolean giro;
        public static final String PLAYER1 = "PLAYER1";
        public static final String PLAYER2 = "PLAYER2";
        public static final String PLAYER3 = "PLAYER3";
        public static final String PLAYER4 = "PLAYER4";

        private String player_1, player_2, player_3, player_4;

        private TextView player1;
        private TextView player2;
        private TextView player3;
        private TextView player4;



        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.gira_garrafa);

                garrafa = findViewById(R.id.garrafa);
                player1 = findViewById(R.id.player1);
                player2 = findViewById(R.id.player2);
                player3 = findViewById(R.id.player3);
                player4 = findViewById(R.id.player4);

                Intent intent = getIntent();
                player_1 = intent.getStringExtra(PLAYER1);
                player_2 = intent.getStringExtra(PLAYER2);
                player_3 = intent.getStringExtra(PLAYER3);
                player_4 = intent.getStringExtra(PLAYER4);

                player1.setText(""+ player_1);
                player2.setText(""+ player_2);
                player3.setText(""+ player_3);
                player4.setText(""+ player_4);





        }
        private  void mensagem(String mensagem){
                new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                                Toast.makeText(GiraGarrafa.this, mensagem, Toast.LENGTH_SHORT).show();
                        }
                },2500);



        }
        public void giraGarrafa(View view) {

                if (!giro) {
                        int novaDir = random.nextInt(3600);
                        int pos;
                        float pivotX = garrafa.getWidth() / 2;
                        float pivotY = garrafa.getHeight() / 2;


                        if(!player_1.isEmpty() && !player_2.isEmpty() && !player_3.isEmpty() && !player_4.isEmpty()) {
                        Animation rotacao = new RotateAnimation(ultDir, novaDir, pivotX, pivotY);
                        rotacao.setDuration(2500);
                        rotacao.setFillAfter(true);
                        rotacao.setAnimationListener(new Animation.AnimationListener() {
                                @Override
                                public void onAnimationStart(Animation animation) {
                                        giro = true;
                                }

                                @Override
                                public void onAnimationEnd(Animation animation) {
                                        giro = false;
                                }


                                @Override
                                public void onAnimationRepeat(Animation animation) {

                                }
                        });
                        pos = novaDir;

                        ultDir = novaDir;
                        garrafa.startAnimation(rotacao);


                                if ((novaDir % 360 >= 0) && (novaDir % 360 < 90)) {

                                        mensagem(player_1 + " bebe. " );
                                }
                                if ((novaDir % 360 >= 90) && (novaDir % 360 < 180)) {

                                        mensagem(player_2 + " bebe. " );                                }
                                if ((novaDir % 360 >= 180) && (novaDir % 360 < 270)) {

                                        mensagem(player_3 + " bebe. " );                                }
                                if ((novaDir % 360 >= 270) && (novaDir % 360 <= 359)) {

                                        mensagem(player_4 + " bebe. " );                                }
                        }
                        else{
                                Toast.makeText(this, "'Informe o nome dos 4 jogadores. Volte e arrume mais amigos.", Toast.LENGTH_SHORT).show();
                        }

                }

        }


}