package br.com.up.giragarrafa.Adapter;


public class JogadasAdapter {
}
